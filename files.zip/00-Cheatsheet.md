# برگه تقلب Fabric (DP-600 / DP-700)

> قبل از شروع سوال‌ها یک بار بخونش. اگر هر بخش رو نمی‌تونی با کلمات خودت توضیح بدی، همون‌جا ضعف داری.

## ۱. معماری کلی
- **OneLake**: یک لایه‌ی ذخیره‌سازی منطقی برای کل tenant ("OneDrive برای داده"). فرمت جدول‌ها **Delta (Parquet + _delta_log)** است. همه‌ی workloadها از همین یک کپی داده استفاده می‌کنن.
- **Capacity**: واحد محاسبه (CU). SKUهای F2 تا F2048، به‌علاوه‌ی Trial و Power BI Premium (P). **Bursting** (استفاده‌ی موقت بیشتر از ظرفیت) و **Smoothing** (پخش مصرف روی زمان) داریم. اگر مصرف از حد بگذره **Throttling** رخ می‌ده. مصرف رو با **Capacity Metrics app** ببین.
- **Workspace**: مرز مدیریت، امنیت و ALM. هر workspace به یک capacity وصله.
- **Domain**: گروه‌بندی workspaceها برای حاکمیت داده (Data Mesh).

## ۲. انتخاب ابزار ذخیره‌سازی/پردازش
| نیاز | انتخاب |
|---|---|
| Spark، Python، داده‌ی نیمه‌ساخت‌یافته، Data Engineering | **Lakehouse** (+ SQL analytics endpoint فقط‌خواندنی) |
| T-SQL کامل (DML)، تراکنش چندجدولی، تیم SQL | **Warehouse** |
| جریان داده/لاگ/IoT با تاخیر کم، KQL | **Eventhouse (KQL DB)** |
| کپی لحظه‌ای از DB عملیاتی بدون ETL | **Mirroring** |
| دسترسی به داده‌ی بیرونی بدون کپی | **Shortcut** (ADLS, S3, GCS, Dataverse, OneLake دیگر) |

## ۳. ورود و تبدیل داده
- **Pipeline** (Data Factory): ارکستریشن، Copy activity، ForEach، Lookup، If Condition، پارامتر و Expression.
- **Dataflow Gen2**: Power Query، low-code، مقصد: Lakehouse/Warehouse و غیره.
- **Notebook**: PySpark/Spark SQL/Python. **Environment** برای کتابخانه‌ها و config. **Starter pool** برای شروع سریع.
- **COPY INTO** و **CTAS**: ورود سریع به Warehouse.
- الگوی **Incremental**: ستون Watermark، MERGE، CDC. همیشه به **Idempotent بودن** (اجرای دوباره، نتیجه‌ی یکسان) فکر کن.

## ۴. Delta Lake
- **OPTIMIZE**: فشرده‌سازی فایل‌های کوچک (bin-packing). با **ZORDER BY** ترتیب داده بر اساس ستون فیلتر.
- **VACUUM**: پاک‌کردن فایل‌های قدیمی. retention پیش‌فرض **۷ روز**.
- **V-Order**: بهینه‌سازی زمان نوشتن Parquet برای خواندن سریع در Power BI/SQL/Spark. روی مصرف نوشتن اثر داره.
- **Time travel**: `VERSION AS OF` و `TIMESTAMP AS OF`، با `DESCRIBE HISTORY` تاریخچه‌ رو ببین.
- **MERGE INTO**: upsert و SCD. **Optimize write** و **auto compaction** مشکل فایل کوچک رو کم می‌کنن.
- Partition فقط برای ستون با cardinality پایین و جدول‌های خیلی بزرگ. over-partitioning یعنی فایل‌های کوچک زیاد.
- **Medallion**: Bronze (خام)، Silver (تمیز، dedupe، تایپ‌شده)، Gold (مدل تحلیلی/star).

## ۵. Warehouse
- بدون distribution/index دستی (برخلاف Synapse dedicated pool)، آمار خودکار، snapshot isolation.
- **Zero-copy clone**: `CREATE TABLE ... AS CLONE OF ...`
- **Time travel** با `OPTION (FOR TIMESTAMP AS OF ...)`.
- امنیت: `GRANT/DENY`، **RLS** (Security Policy + inline TVF)، **CLS**، **Dynamic Data Masking**.

## ۶. Semantic Model / DAX
- **Star schema**: Fact + Dimension، رابطه‌ی one-to-many، جهت فیلتر ترجیحاً single.
- حالت‌های ذخیره: **Import**، **DirectQuery**، **Direct Lake**، **Composite**.
- **Direct Lake**: خواندن فایل‌های Delta مستقیم به حافظه (framing/transcoding). در حالت **Direct Lake on SQL endpoint** در شرایطی (مثل view، RLS در SQL endpoint، عبور از guardrail) **fallback به DirectQuery** داره. در **Direct Lake on OneLake** این fallback وجود نداره.
- DAX: `CALCULATE`، filter context در برابر row context، context transition، `SUMX`/iteratorها، `DIVIDE`، `VAR/RETURN`، time intelligence (نیاز به **Date table** علامت‌خورده)، `TREATAS`، `USERELATIONSHIP`.
- **Calculation groups** (با Tabular Editor)، **Incremental refresh** (پارامترهای `RangeStart`/`RangeEnd`)، **XMLA endpoint**.
- ابزارها: Performance Analyzer، DAX Studio، VertiPaq Analyzer، Tabular Editor + BPA.

## ۷. امنیت و حاکمیت
- نقش‌های Workspace: **Admin > Member > Contributor > Viewer**.
- سطوح: Tenant → Capacity → Workspace → Item permission → OneLake data access roles → SQL (GRANT/RLS/CLS/DDM) → Semantic model (RLS/OLS).
- **Sensitivity labels** (Purview)، **Endorsement** (Promoted/Certified)، **Lineage** و **Impact analysis**.

## ۸. ALM و عملیات
- **Git integration**: Azure DevOps و GitHub، با branch و commit/update.
- **Deployment pipelines**: Dev → Test → Prod با **deployment rules** (تغییر پارامتر/منبع در هر مرحله).
- **Monitoring hub**، **Spark UI/History server**، جزئیات اجرای pipeline، **Capacity Metrics app**.

## ۹. Real-Time Intelligence
- **Eventstream** (ورود/تبدیل/مسیردهی) → **Eventhouse/KQL DB** → **KQL Queryset** / **Real-Time Dashboard** → **Activator** (اکشن روی شرط).
- KQL پایه: `where`، `project`، `extend`، `summarize ... by bin(ts, 5m)`، `join`، `top`، `render timechart`.
- سیاست‌ها: **retention**، **caching**، **update policy**، **materialized view**، **ingestion mapping**.
